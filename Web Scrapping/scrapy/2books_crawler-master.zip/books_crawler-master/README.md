# Books Crawler
A Scrapy crawler for http://books.toscrape.com
